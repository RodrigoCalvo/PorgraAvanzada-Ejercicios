package ejercicio;

public abstract class EstadoPirata {
	public int ataque;
	public int defensa;
	public abstract EstadoPirata beberGrog();
	public abstract EstadoPirata beberJugo();
}
