package ejercicio;

public enum Sexo {
	F,
	M
}
